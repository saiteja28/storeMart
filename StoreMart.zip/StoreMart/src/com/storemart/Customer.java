package com.storemart;

import java.util.Scanner;

public class Customer {
	public int custId;
	public String custName;
	public long mobileNumber;
	public String address;
	public Product product[];
	
	static Scanner scanner=new Scanner(System.in);
	public Customer(int custId, String custName, long mobileNumber, String address) {

		this.custId = custId;
		this.custName = custName;
		this.mobileNumber = mobileNumber;
		this.address = address;
	}

	public  Customer() {
	}

	
	public int[] buyProduct(Product product[]){
		boolean flag=true;
		int[] productId=new int[product.length];
		int i=0;
		System.out.println("continue to shop..(yes/no)");
		while(flag){
			
			String option=scanner.nextLine();
			if(option.equalsIgnoreCase("yes")){
				flag=true;
				System.out.println("Enter product id to buy");
				productId[i]=scanner.nextInt();
				i++;
			}else{
				flag=false;
			}
		}
		int[] prods=new int[i];
		for(int j=0;j<prods.length;j++){
			prods[j]=productId[j];
		}
		
		return prods;
		
	}

}
