package com.storemart;

public class Product {
	public  int productId;
	public String productName;
	public double price;
	public int pDiscount;
	
	public Product(){
		
	}
	public Product(int productId, String productName, double price, int pDiscount) {
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.pDiscount = pDiscount;
	}
	
	public void getProductDetails(){
		System.out.println(productId+"\t"+productName+"\t"+"\t"+price+"\t"+pDiscount);
	}

}
