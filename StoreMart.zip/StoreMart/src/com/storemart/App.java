package com.storemart;

import java.util.Scanner;

public class App {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		Product product[] = new Product[5];
		product[0] = new Product(101, "Body Lotion", 86.50, 10);
		product[1] = new Product(102, "Chandrika Soap", 16.50, 5);
		product[2] = new Product(103, "Clinic Plus", 56.75, 6);
		product[3] = new Product(104, "SunFlower Oil", 86.50, 10);
		product[4] = new Product(105, "Surf Excel", 80.50, 10);
		System.out.println("--------------------Products details--------------");
		System.out.println("ProductId\tProductName\tPrice\tDiscount");
		System.out.println("--------------------------------------------");
		for (int i = 0; i < product.length; i++) {
			product[i].getProductDetails();
		}
		Customer[] customer=new Customer[10];
		customer[0]=new Customer(336, "teja", 8686734334l, "Hyd");
		
		int[] prodId=customer[0].buyProduct(product);
		for(int i=0;i<prodId.length;i++){
			System.out.println(prodId[i]);
		}
		
		int mapping[][]=new int[product.length][2];
		int custId=customer[0].custId;
		for(int i=0;i<prodId.length;i++){
			for(int j=0;j<=1;j++){
				if(j==0){
					mapping[i][j]=custId;
				}else if(j==1){
					mapping[i][j]=prodId[i];
				}
			}
		}
		System.out.println("Customer Id\t Product Id");
		for(int i=0;i<prodId.length;i++){
			for(int j=0;j<=1;j++){
				System.out.print(mapping[i][j]+"\t \t");
			}
			System.out.println("\n");
		}
				
		
		scanner.close();
	}

}
